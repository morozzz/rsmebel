<?php

class HomeNew extends AppModel {
    var $name = 'HomeNew';
    var $order = 'priority';
}

?>
