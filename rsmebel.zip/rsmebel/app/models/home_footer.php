<?php

class HomeFooter extends AppModel {
    var $name = 'HomeFooter';
}

?>
