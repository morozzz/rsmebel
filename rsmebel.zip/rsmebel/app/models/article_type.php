<?php

class ArticleType extends AppModel {
    var $name = 'ArticleType';

    var $field_types = array(
        'name' => 'text'
    );
}

?>
