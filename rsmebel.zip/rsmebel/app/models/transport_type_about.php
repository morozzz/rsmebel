<?php

class TransportTypeAbout extends AppModel {
    var $name = 'TransportTypeAbout';
}

?>
