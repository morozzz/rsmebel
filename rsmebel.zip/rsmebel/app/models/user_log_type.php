<?php

class UserLogType extends AppModel {
    var $name = 'UserLogType';
}

?>
