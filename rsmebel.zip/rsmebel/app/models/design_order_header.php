<?php

class DesignOrderHeader extends AppModel {
    var $name = 'DesignOrderHeader';
}

?>
