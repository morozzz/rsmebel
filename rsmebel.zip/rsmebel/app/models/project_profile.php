<?php

class ProjectProfile extends AppModel {
    var $name = 'ProjectProfile';

    var $order = 'name';
}

?>
