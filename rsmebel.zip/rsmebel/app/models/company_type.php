<?php

class CompanyType extends AppModel {
    var $name = 'CompanyType';
    var $displayField = 'type_name';
}

?>
