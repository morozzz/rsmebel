<?php

class StringType extends AppModel {
    var $name = 'StringType';
}

?>
