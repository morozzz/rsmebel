<?php

class Dispatch extends AppModel {
    var $name = 'Dispatch';
    var $transactional = true;
}

?>
