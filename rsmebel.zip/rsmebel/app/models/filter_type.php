<?php

class FilterType extends AppModel {
    var $name = 'FilterType';

    var $hasMany = array(
        'Filter'
    );
}
?>
