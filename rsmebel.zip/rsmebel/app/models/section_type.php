<?php

class SectionType extends AppModel {
    var $name = 'SectionType';
    var $hasMany = 'Section';
}

?>
