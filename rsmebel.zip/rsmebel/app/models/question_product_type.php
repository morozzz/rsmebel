<?php

class QuestionProductType extends AppModel {
    var $name = 'QuestionProductType';
    var $order = 'QuestionProductType.id';
}

?>
