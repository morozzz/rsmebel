<?php

class PurchaseRule extends AppModel {
    var $name = 'PurchaseRule';
}

?>
