<?php

class CompanyInfo extends AppModel {
    var $name = 'CompanyInfo';

    var $order = 'CompanyInfo.sort_order';
}

?>
