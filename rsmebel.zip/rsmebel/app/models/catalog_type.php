<?php

class CatalogType extends AppModel {
    var $name = 'CatalogType';
}

?>
