<?php

class TransportAddress extends AppModel {
    var $name = 'TransportAddress';
}
?>
