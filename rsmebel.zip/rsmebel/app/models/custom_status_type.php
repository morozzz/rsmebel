<?php

class CustomStatusType extends AppModel {
    var $name = 'CustomStatusType';
    var $belongsTo = array(
        'Image'
    );
}

?>
