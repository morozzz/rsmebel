<?php

class ProfilType extends AppModel {
    var $name = 'ProfilType';
    var $displayField = 'profil_name';
}

?>
