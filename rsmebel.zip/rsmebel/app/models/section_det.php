<?php

class SectionDet extends AppModel {
    var $name = 'SectionDet';
    var $belongsTo = 'Section';
}

?>
