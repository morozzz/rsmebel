<?php

class DesignOrderStatus extends AppModel {
    var $name = 'DesignOrderStatus';
}

?>
