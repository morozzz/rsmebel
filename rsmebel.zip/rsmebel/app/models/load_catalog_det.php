<?php

class LoadCatalogDet extends AppModel {
    var $name = 'LoadCatalogDet';
    var $belongsTo = 'LoadCatalog';
}

?>
