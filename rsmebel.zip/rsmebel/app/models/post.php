<?php

class Post extends AppModel {
    var $name = 'Post';
    var $tablePrefix = 'phpbb_';
}

?>
