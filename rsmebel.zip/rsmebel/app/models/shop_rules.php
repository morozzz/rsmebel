<?php

class ShopRule extends AppModel {
    var $name = 'ShopRule';
}

?>
