<?php

class DesignInfo extends AppModel {
    var $name = 'DesignInfo';
}

?>
