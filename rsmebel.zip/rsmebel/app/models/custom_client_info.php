<?php
class CustomClientInfo extends AppModel {

    var $name = 'CustomClientInfo';
    var $belongsTo = array("CompanyType");
}
?>
