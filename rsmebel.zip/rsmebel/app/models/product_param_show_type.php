<?php

class ProductParamShowType extends AppModel {
    var $name = 'ProductParamShowType';

    var $caches = array(
        'product_param_show_type_list',
        'all_catalogs'
    );
}

?>
