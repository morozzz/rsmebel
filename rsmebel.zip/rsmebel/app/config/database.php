<?php

class DATABASE_CONFIG {

	var $default = array(
		'driver' => 'mysql',
                'encoding' => 'utf8',
		'persistent' => false,
		'host' => '127.0.0.1',
		'login' => 'rsmebel',
		'password' => 'vfrfhjys',
		'database' => 'rsmebel',
		'prefix' => 'cake_',
	);
}
?>
