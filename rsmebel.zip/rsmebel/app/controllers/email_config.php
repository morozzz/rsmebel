<?php
//  $email_config = array(
//          'port'=>'25',
//          'timeout'=>'30',
//          'host' => 'mail.core.kran',
//          'username'=>'i.morozov@krasinform.ru',
//          'password'=>'ytrjyz');

//  $email_config = array(
//          'port'=>'25',
//          'timeout'=>'30',
//          'host' => 'smtp.angelika-krsk.ru',
//          'username'=>'postmaster@angelika-krsk.ru',
//          'password'=>'bultic6lle4');

  $email_config = array(
          'port'=>'25',
          'timeout'=>'30',
          'host' => 'smtp.avto-guide.com',
          'username'=>'info@avto-guide.com',
          'password'=>'1');

?>
